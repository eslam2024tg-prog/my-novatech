// يُنشئ قاعدة البيانات site.db ويملأها بالبيانات الافتراضية لو كانت فارغة.
// يعمل تلقائياً عند أول تشغيل للسيرفر (server.js) أيضاً، لكن يمكن تشغيله يدوياً:
//   node database/seed.js
'use strict';
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { DatabaseSync } = require('node:sqlite');

const DB_PATH = path.join(__dirname, 'site.db');
const SCHEMA_PATH = path.join(__dirname, 'schema.sql');
const DEFAULT_PASSWORD = 'admin123';

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

function seed() {
  const db = new DatabaseSync(DB_PATH);
  db.exec(fs.readFileSync(SCHEMA_PATH, 'utf8'));

  const settingsRow = db.prepare('SELECT COUNT(*) AS c FROM settings').get();
  if (settingsRow.c === 0) {
    db.prepare(`INSERT INTO settings
      (id, site_name, hero_sub, about, phone, whatsapp, email, address, hours, logo_image)
      VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, NULL)`).run(
      'نوفا تك',
      'توريد وتركيب وصيانة أنظمة المراقبة والكاميرات وأجهزة التسجيل والبصمات وجميع الوصلات والكابلات المرتبطة بها، بخبرة فنية وضمان حقيقي.',
      'نوفا تك (NTT) شركة متخصصة في بيع وتركيب أنظمة المراقبة والحماية، نوفر كاميرات المراقبة بمختلف أنواعها، أجهزة التسجيل DVR وNVR، أنظمة البصمة والدخول، إضافة إلى كافة الوصلات والكابلات اللازمة. نحرص على تقديم منتجات موثوقة وخدمة تركيب احترافية وصيانة مستمرة لعملائنا.',
      '+966 5xx xxx xxx',
      '+966 5xx xxx xxx',
      'info@novatech-ntt.com',
      'الرياض، المملكة العربية السعودية',
      'السبت - الخميس، 9ص - 9م'
    );
    console.log('تم إدخال بيانات الموقع الافتراضية.');
  }

  const catRow = db.prepare('SELECT COUNT(*) AS c FROM categories').get();
  if (catRow.c === 0) {
    const cats = [
      ['surv', 'أنظمة المراقبة الشاملة', 'SURV-SYS', 'shield', 1],
      ['cam', 'الكاميرات', 'CAM-SERIES', 'camera', 2],
      ['dvr', 'أجهزة التسجيل DVR / NVR', 'REC-DVR', 'dvr', 3],
      ['finger', 'أجهزة البصمة والدخول', 'BIO-ACCESS', 'finger', 4],
      ['cable', 'الكابلات والوصلات', 'CABLE-KIT', 'cable', 5]
    ];
    const stmt = db.prepare('INSERT INTO categories (id, name, code, icon, sort_order) VALUES (?, ?, ?, ?, ?)');
    for (const c of cats) stmt.run(...c);
    console.log('تم إدخال التصنيفات الافتراضية.');
  }

  const prodRow = db.prepare('SELECT COUNT(*) AS c FROM products').get();
  if (prodRow.c === 0) {
    const products = [
      ['p1', 'surv', null, 'باقة مراقبة منزلية متكاملة', '4 كاميرات + جهاز تسجيل + تركيب', '', null, 1],
      ['p2', 'cam', null, 'كاميرا خارجية ليلية HD', 'دقة عالية مع رؤية ليلية', '', null, 1],
      ['p3', 'cam', null, 'كاميرا داخلية دوارة WiFi', 'تحكم عن بعد عبر التطبيق', '', null, 1],
      ['p4', 'dvr', null, 'جهاز تسجيل NVR 8 قنوات', 'دعم تخزين حتى 4TB', '', null, 1],
      ['p5', 'finger', null, 'جهاز بصمة ووجه للدخول', 'مناسب للمكاتب والمنشآت', '', null, 1],
      ['p6', 'cable', null, 'كابل شبكة CAT6 - 305م', 'لمشاريع الشبكات والمراقبة', '', null, 1],
      ['hik1', 'cam', 'Hikvision', 'DS-2CD2387G2-LU — كاميرا ColorVu تيريت', '8 ميجابكسل (4K)، ألوان كاملة ليلاً، ميكروفون مدمج', '', null, 1],
      ['hik2', 'cam', 'Hikvision', 'DS-2CD2143G2-I — كاميرا AcuSense قبة', '4 ميجابكسل، كشف ذكي للأشخاص والمركبات', '', null, 1],
      ['hik3', 'cam', 'Hikvision', 'DS-2CD2T47G2-L — كاميرا ColorVu بولت خارجية', '4 ميجابكسل، مدى رؤية ليلية طويل حتى 60م', '', null, 1],
      ['hik4', 'dvr', 'Hikvision', 'DS-7616NXI-K2 — جهاز NVR شبكي 16 قناة', 'دعم تسجيل حتى 4K لكل قناة، منفذا أقراص صلبة', '', null, 1],
      ['hik5', 'dvr', 'Hikvision', 'iDS-7208HUHI-M2/S — جهاز DVR هجين 8 قنوات', 'يدعم كاميرات HD-TVI وIP معاً مع تحليل AcuSense', '', null, 1]
    ];
    const stmt = db.prepare(`INSERT INTO products (id, cat, brand, name, desc, price, image, placeholder)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);
    for (const p of products) stmt.run(...p);
    console.log('تم إدخال المنتجات الافتراضية.');
  }

  const adminRow = db.prepare('SELECT COUNT(*) AS c FROM admin').get();
  if (adminRow.c === 0) {
    db.prepare('INSERT INTO admin (id, password_hash) VALUES (1, ?)').run(hashPassword(DEFAULT_PASSWORD));
    console.log(`تم إنشاء حساب المدير. كلمة المرور الافتراضية: ${DEFAULT_PASSWORD}`);
  }

  db.close();
  console.log('قاعدة البيانات جاهزة في: ' + DB_PATH);
}

if (require.main === module) {
  seed();
}

module.exports = { seed, hashPassword, DB_PATH };
