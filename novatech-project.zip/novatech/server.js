'use strict';
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const { DatabaseSync } = require('node:sqlite');
const { seed, hashPassword, DB_PATH } = require('./database/seed.js');

// تأكد أن قاعدة البيانات موجودة ومهيأة قبل بدء الخادم
seed();

const db = new DatabaseSync(DB_PATH);
const app = express();
app.use(express.json({ limit: '15mb' })); // الصور تُرسل كـ base64 لذا نحتاج حد أعلى
app.use(express.static(path.join(__dirname, 'public')));

const PORT = process.env.PORT || 3000;

// ---------- أدوات مساعدة ----------
function verifyPassword(password, stored) {
  const [salt, hash] = stored.split(':');
  const check = crypto.scryptSync(password, salt, 64).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(check, 'hex'));
}

// جلسات بسيطة في الذاكرة (تكفي لوحة تحكم بمدير واحد)
const sessions = new Map(); // token -> expiry timestamp
const SESSION_TTL_MS = 12 * 60 * 60 * 1000; // 12 ساعة

function createSession() {
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, Date.now() + SESSION_TTL_MS);
  return token;
}

function requireAuth(req, res, next) {
  const auth = req.headers.authorization || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : null;
  const expiry = token && sessions.get(token);
  if (!expiry || expiry < Date.now()) {
    return res.status(401).json({ error: 'غير مصرح، الرجاء تسجيل الدخول' });
  }
  next();
}

function rowToSettings(row) {
  if (!row) return null;
  return {
    siteName: row.site_name,
    heroSub: row.hero_sub,
    about: row.about,
    phone: row.phone,
    whatsapp: row.whatsapp,
    email: row.email,
    address: row.address,
    hours: row.hours,
    logoImage: row.logo_image || undefined
  };
}

function rowToProduct(row) {
  return {
    id: row.id,
    cat: row.cat,
    brand: row.brand || undefined,
    name: row.name,
    desc: row.desc,
    price: row.price,
    image: row.image,
    placeholder: !!row.placeholder
  };
}

// ---------- مسارات عامة (بدون تسجيل دخول) ----------
app.get('/api/settings', (req, res) => {
  const row = db.prepare('SELECT * FROM settings WHERE id = 1').get();
  res.json(rowToSettings(row) || {});
});

app.get('/api/categories', (req, res) => {
  const rows = db.prepare('SELECT * FROM categories ORDER BY sort_order ASC').all();
  res.json(rows.map(r => ({ id: r.id, name: r.name, code: r.code, icon: r.icon })));
});

app.get('/api/products', (req, res) => {
  const rows = db.prepare('SELECT * FROM products ORDER BY rowid ASC').all();
  res.json(rows.map(rowToProduct));
});

// ---------- تسجيل الدخول ----------
app.post('/api/login', (req, res) => {
  const { password } = req.body || {};
  const row = db.prepare('SELECT password_hash FROM admin WHERE id = 1').get();
  if (!row || !password || !verifyPassword(password, row.password_hash)) {
    return res.status(401).json({ error: 'كلمة المرور غير صحيحة' });
  }
  const token = createSession();
  res.json({ token });
});

app.post('/api/change-password', requireAuth, (req, res) => {
  const { newPassword } = req.body || {};
  if (!newPassword || !newPassword.trim()) {
    return res.status(400).json({ error: 'اكتب كلمة مرور جديدة' });
  }
  db.prepare('UPDATE admin SET password_hash = ? WHERE id = 1').run(hashPassword(newPassword.trim()));
  res.json({ ok: true });
});

// ---------- مسارات محمية (تحتاج تسجيل دخول) ----------
app.put('/api/settings', requireAuth, (req, res) => {
  const s = req.body || {};
  db.prepare(`UPDATE settings SET site_name=?, hero_sub=?, about=?, phone=?, whatsapp=?, email=?, address=?, hours=? WHERE id=1`)
    .run(s.siteName || '', s.heroSub || '', s.about || '', s.phone || '', s.whatsapp || '', s.email || '', s.address || '', s.hours || '');
  const row = db.prepare('SELECT * FROM settings WHERE id = 1').get();
  res.json(rowToSettings(row));
});

app.put('/api/settings/logo', requireAuth, (req, res) => {
  const { logoImage } = req.body || {};
  db.prepare('UPDATE settings SET logo_image = ? WHERE id = 1').run(logoImage || null);
  res.json({ ok: true });
});

app.post('/api/products', requireAuth, (req, res) => {
  const p = req.body || {};
  if (!p.name || !p.name.trim()) return res.status(400).json({ error: 'اكتب اسم المنتج' });
  const id = 'p' + Date.now();
  db.prepare(`INSERT INTO products (id, cat, brand, name, desc, price, image, placeholder)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(id, p.cat || '', p.brand || null, p.name.trim(), p.desc || '', p.price || '', p.image || null, p.image ? 0 : 1);
  const row = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
  res.json(rowToProduct(row));
});

app.put('/api/products/:id', requireAuth, (req, res) => {
  const existing = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'المنتج غير موجود' });
  const p = req.body || {};
  const image = p.image || existing.image;
  db.prepare(`UPDATE products SET cat=?, brand=?, name=?, desc=?, price=?, image=?, placeholder=0 WHERE id=?`)
    .run(p.cat || existing.cat, p.brand || null, p.name || existing.name, p.desc || '', p.price || '', image, req.params.id);
  const row = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  res.json(rowToProduct(row));
});

app.delete('/api/products/:id', requireAuth, (req, res) => {
  db.prepare('DELETE FROM products WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

app.listen(PORT, () => {
  console.log(`الخادم يعمل على المنفذ ${PORT}`);
  console.log(`الموقع:        http://localhost:${PORT}/`);
  console.log(`لوحة التحكم:  http://localhost:${PORT}/admin.html`);
});
